<?php

    require_once 'dbconnect.php';

    $bcode = $_POST['barcode'];
    $p_name = $_POST['pname'];
    $b_name = $_POST['bname'];
    $prz = $_POST['price'];
    $size = $_POST['size'];
    $color = $_POST['color'];
    $disc = $_POST['discount'];
    $qty = $_POST['quantity'];

    $limit = count($bcode);

    for($i=0;$i<$limit;$i++) 
    {
        $barcode[$i] = mysqli_real_escape_string($connect,$bcode[$i]);
        $pname[$i] = mysqli_real_escape_string($connect,$p_name[$i]);
        $bname[$i] = mysqli_real_escape_string($connect,$b_name[$i]);
        $price[$i] = mysqli_real_escape_string($connect,$prz[$i]);
        $size[$i] = mysqli_real_escape_string($connect,$size[$i]);
        $color[$i] = mysqli_real_escape_string($connect,$color[$i]);
        $discount[$i] = mysqli_real_escape_string($connect,$disc[$i]);
        $quantity[$i] = mysqli_real_escape_string($connect,$qty[$i]);

        $sql = "INSERT INTO products(barcode, pname, bname, price, size, color, discount, qty) VALUES 
        ('".$barcode[$i]."', '".$pname[$i]."', '".$bname[$i]."', '".$price[$i]."', '".$size[$i]."', '".$color[$i]."', '".$discount[$i]."', '".$quantity[$i]."')";

        $sql1 = "INSERT INTO update_products(barcode, update_qty) VALUES ('".$barcode[$i]."', '".$quantity[$i]."')";

        if ($connect->query($sql) === TRUE) {

            if ($connect->query($sql1) === TRUE) {

                echo '<script language="javascript">';
                echo 'alert("Details Saved Successfully")';
                echo '</script>';
                echo '<script language="javascript">';
                echo "window.location='addproduct.php'";
                echo '</script>';	
                
            } else {
                echo "Error: " . $sql1 . "<br>" . $connect->error;
            }
        }
        else {
            echo "Error: " . $sql . "<br>" . $connect->error;
        }

    }

	

?>