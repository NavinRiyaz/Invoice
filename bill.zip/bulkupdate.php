<?php

    echo "Bulk update";

?>