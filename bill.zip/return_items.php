<?php   

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['return_check'])) {
        
        $values = $_POST['return_check'];

        $sql = "SELECT * FROM products WHERE barcode = '".$values."'";
        $result = $connect->query($sql);
        $checkrows = mysqli_num_rows($result);
        if($checkrows > 0) 
        {
            while ($row = mysqli_fetch_array($result)) 
            {
                $barcode = $row['barcode'];
                $pname = $row['pname'];
                $bname = $row['bname'];
                $price = $row['price'];
                $size = $row['size'];
                $color = $row['color'];

                $sql1 = "INSERT INTO return_items(re_item_barcode, re_item_name, re_item_brand, re_item_price, re_item_size, re_item_color) 
                VALUES ('".$barcode."', '".$pname."', '".$bname."', '".$price."', '".$size."', '".$color."')";

                $result1 = $connect->query($sql1);

                if ($result1 === TRUE) {
                    
                    $sql2 = "UPDATE products SET qty = qty+1 WHERE barcode = '".$barcode."'";
                    $result2 = $connect->query($sql2);

                    if ($result2 === TRUE) {
                        
                        $sql3 = "UPDATE sales SET subtotal = subtotal - '".$price."', total_amount = total_amount - '".$price."', gst_total = gst_total - '".$price."', quantity_count = quantity_count - 1 ";
                        $result3 = $connect->query($sql3);

                        if ($result3 === TRUE) {
                            
                            $sql4 = "DELETE FROM items WHERE barcode = '".$barcode."'";
                            $result4 = $connect->query($sql4);
    
                        }
                            

                    }

                }
            
            }
        }
    }



?>