/*
I am still having problems with 2 video sources. Sometimes they don't load together and videos can go out of sync. If anybody has any ideas about that, please leave a comment. Thanks.
*/