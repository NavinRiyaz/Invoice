<?php  
    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['insert'])) {

        $id = $_POST['employee_id'];
        $sales_name = $_POST['edit_sales_name'];
        $sales_phone = $_POST['edit_sales_phone'];
        $sales_username = $_POST['edit_sales_username'];
        $sales_password = $_POST['edit_sales_password'];

        $sql = "UPDATE salesman SET sales_name='$sales_name', sales_phone='$sales_phone', sales_username='$sales_username', sales_password='$sales_password' WHERE sales_id = '$id'";

        if($connect->query($sql) === TRUE) {
            header("Location: salesman.php");
        } else {
            echo 'cancel';
        }

    }

 
?>