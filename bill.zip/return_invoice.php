<?php

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['re_invoice'])) {

        $invoice = $_POST['re_invoice'];
        header("Location: return.php?id=$invoice");        

    }

?>