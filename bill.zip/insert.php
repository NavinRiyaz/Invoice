<?php  
    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['insert'])) {

        $id = $_POST['employee_id'];
        $pr_name = $_POST['epname'];
        $br_name = $_POST['ebname'];
        $price = $_POST['eprice'];
        $type = $_POST['etype'];
        $discount = $_POST['ediscount'];

        $sql = "UPDATE products SET pname='$pr_name', bname='$br_name', price='$price', type='$type', discount='$discount' WHERE p_id = '$id'";

        if($connect->query($sql) === TRUE) {
            header("Location: products.php");
        } else {
            echo 'cancel';
        }

    }

 
?>