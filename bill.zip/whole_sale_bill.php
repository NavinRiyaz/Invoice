<?php
    
    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['submit'])) {

        $name = $_POST['cust_name'];
        $phone = $_POST['cust_phone'];
        $bill = $_POST['bill_code'];
        $gst = $_POST['cust_gst'];
        $qty = $_POST['quantity_count'];
        $subtotal = $_POST['subtotal'];
        $payment_method = $_POST['payment_method'];
        $discount = $_POST['totalDiscount'];
        $total = $_POST['all_total'];
        $overall = $_POST['overall'];
        $gst_total = $_POST['gsttotal'];
        $state = $_POST['state'];
        $money = $_POST['money'];
        $change = $_POST['change_amount'];

        $sql = "INSERT INTO whole_sale_detail(bill_code, w_name, w_phone, w_gst_number, w_quantity, w_subtotal, w_cash_method, w_discount, w_total, w_gst_total, w_state_method, w_cash, w_change) 
        VALUES ('".$bill."', '".$name."', '".$phone."', '".$gst."', '".$qty."', '".$subtotal."', '".$payment_method."', '".$discount."', '".$overall."', '".$gst_total."', '".$state."', '".$money."', '".$change."')";
        $result = $connect->query($sql);

            if ($result === TRUE) {
                
                $whole_bill = "SELECT * FROM whole_items WHERE bill_code = '".$bill."'";
                $whole_result = $connect->query($whole_bill);
                while ($row = mysqli_fetch_array($whole_result)) {

                    $bill_number = $row['bill_code'];
                    $pname = $row['w_pname'];
                    $bname = $row['w_bname'];
                    $price = $row['w_price'];
                    $size = $row['w_size'];
                    $color = $row['w_color'];
                    $qty = $row['w_qty'];


                $whole_sale_bill = "SELECT * FROM whole_sale_detail WHERE bill_code = '".$bill."'";
                $whole_sale_result = $connect->query($whole_sale_bill);
                while ($rowas = mysqli_fetch_array($whole_sale_result)){

                    $name = $rowas['w_name'];
                    $phone = $rowas['w_phone'];
                    $gst = $rowas['w_gst_number'];
                    $count_qty = $rowas['w_quantity'];
                    $total_sub = $rowas['w_subtotal'];
                    $disc = $rowas['w_discount'];
                    $amount_total = $rowas['w_total'];
                    $total_gst = $rowas['w_gst_total'];
                    $method_gst = $rowas['w_state_method'];
                    $amount_money = $rowas['w_cash'];

                switch($_POST['state']){
                case 'instate':
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Aclonica" rel="stylesheet">
        
        <style>
            body .container{
                border: black solid 2px;
            }
        </style>
        <style type="text/css">
            .tg  {border-collapse:collapse;border-spacing:0;}
            .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg .tg-xldj{border-color:inherit;text-align:left}
            .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
        </style>

        <title>Receipt</title>
    </head>
    <body onload="self.print()">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p><span style="font-weight:bold;">GSTIN</span> : 33AKIPR8911M1ZN <br> <span style="font-weight:bold;">STATE CODE</span> : 33</p>
                </div>
                <div class="col-md-4 text-center">
                    <p style="font-weight:bold; text-decoration: underline; font-size: 20px;">TAX INVOICE</p>
                </div>
                <div class="col-md-4 text-right">
                    <p><span style="font-weight:bold;">CELL</span> : 98430 75605</p>
                </div>
            </div>
            <div class="text-center">
                <p style="font-weight:bold; font-size: 30px;">ROMAN'S SEAT COVER & HELMETS</p>
                <p>224/115-K, Silver Arrow Complex, Opp. to Infant Jesus Church, <br> Omalur Main Road, (Near Four Roads), SALEM - 636007</p>
            </div>
            <div class="row">
                <div class="col">
                    <p class="text-left">Bill No: <?php echo $bill_number; ?></p>
                </div>
                <div class="col">
                    <p class="text-right"><span>Date : </span><?php echo date("Y/m/d"); ?></p>
                </div>
            </div>
            <div>
                <p style="font-weight:bold;">TO</p>
                <p><span style="font-weight:bold;">Customer Name : </span><?php echo $name; ?></p>
                <p><span style="font-weight:bold;">Phone Number : </span><?php echo $phone ?></p>
                <p><span style="font-weight:bold;">GST Number : </span><?php echo $gst; ?></p>
            </div>
            <div>
            <table class="tg" style="width:100%;">
                    <tr>
                      <th class="tg-s268">S.NO</th>
                      <th class="tg-s268" colspan="4">Product Name</th>
                      <th class="tg-s268">Brand</th>
                      <th class="tg-s268">Size</th>
                      <th class="tg-s268">Color</th>
                      <th class="tg-s268">Qty</th>
                      <th class="tg-s268">Rate</th>
                    </tr>
                    <?php
                        $whole_bill = "SELECT * FROM whole_items WHERE bill_code = '".$bill."'";
                        $whole_result = $connect->query($whole_bill);
                        while ($row = mysqli_fetch_array($whole_result)) {
        
                            $bill_number = $row['bill_code'];
                            $pname = $row['w_pname'];
                            $bname = $row['w_bname'];
                            $price = $row['w_price'];
                            $size = $row['w_size'];
                            $color = $row['w_color'];
                            $qty = $row['w_qty'];
        
                        $sno = 0;
                        $whole_sale_bill = "SELECT * FROM whole_sale_detail WHERE bill_code = '".$bill."'";
                        $whole_sale_result = $connect->query($whole_sale_bill);
                        while ($rowas = mysqli_fetch_array($whole_sale_result)){
        
                            $name = $rowas['w_name'];
                            $phone = $rowas['w_phone'];
                            $gst = $rowas['w_gst_number'];
                            $count_qty = $rowas['w_quantity'];
                            $total_sub = $rowas['w_subtotal'];
                            $disc = $rowas['w_discount'];
                            $amount_total = $rowas['w_total'];
                            $total_gst = $rowas['w_gst_total'];
                            $method_gst = $rowas['w_state_method'];
                            $amount_money = $rowas['w_cash'];

                            $sno = $sno + 1;
                            $gst_amount = $total_gst / 2; 
                    
                    ?>
                    <tr style="margin-top:-10px;">
                        <td class="tg-xldj"><?php echo $sno; ?></td>
                        <td class="tg-xldj" colspan="4"><?php echo $pname; ?></td>
                        <td class="tg-xldj"><?php echo $bname; ?></td>
                        <td class="tg-xldj"><?php echo $color; ?></td>
                        <td class="tg-xldj"><?php echo $size; ?></td>
                        <td class="tg-xldj"><?php echo $qty; ?></td>
                        <td class="tg-xldj"><?php echo $price; ?></td>
                    </tr>
                    <?php 
                            }
                        }
                    ?>
                    <tr>
                      <td class="tg-s268" colspan="8" rowspan="5">Tax Amount in Words</td>
                      <td class="tg-s268" colspan="1">SGST @ 9%</td>
                      <td class="tg-0lax"><?php echo $gst_amount; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">CGST @ 9%</td>
                      <td class="tg-0lax"><?php echo $gst_amount; ?></td>
                    </tr>
                    <tr>
                        <td class="tg-xldj" colspan="1">Subtotal</td>
                        <td class="tg-xldj"><?php echo $total_sub; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Discount %</td>
                      <td class="tg-0lax"><?php echo $disc; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Total Amount</td>
                      <td class="tg-0lax"><?php echo $amount_total;?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="7"  height="300">Goods once sold can't be taken back or Exchange</td>
                      <td class="tg-s268" colspan="4"  height="300">for Roman's Seat Cover &amp; Helmets</td>
                    </tr>
                    <tr>
                    </tr>
                  </table>
            </div>
        </div>      
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        
    </body>
    </html>
<?php
    echo '<meta http-equiv="refresh" content="5; url=whole_sale.php">';
    unset($_SESSION["whole_billing"]);
    break;
    case 'otherstate':
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Aclonica" rel="stylesheet">
        
        <style>
            body .container{
                border: black solid 2px;
            }
        </style>
        <style type="text/css">
            .tg  {border-collapse:collapse;border-spacing:0;}
            .tg td{font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg th{font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg .tg-xldj{border-color:inherit;text-align:left}
            .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
        </style>

        <title>Receipt</title>
    </head>
    <body onload="self.print()">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p><span style="font-weight:bold;">GSTIN</span> : 33AKIPR8911M1ZN <br> <span style="font-weight:bold;">STATE CODE</span> : 33</p>
                </div>
                <div class="col-md-4 text-center">
                    <p style="font-weight:bold; text-decoration: underline; font-size: 20px;">TAX INVOICE</p>
                </div>
                <div class="col-md-4 text-right">
                    <p><span style="font-weight:bold;">CELL</span> : 98430 75605</p>
                </div>
            </div>
            <div class="text-center">
                <p style="font-weight:bold; font-size: 30px;">ROMAN'S SEAT COVER & HELMETS</p>
                <p>224/115-K, Silver Arrow Complex, Opp. to Infant Jesus Church, <br> Omalur Main Road, (Near Four Roads), SALEM - 636007</p>
            </div>
            <div class="row">
                <div class="col">
                    <p class="text-left">Bill No: <?php echo $bill_number; ?></p>
                </div>
                <div class="col">
                    <p class="text-right"><span>Date : </span><?php echo date("Y/m/d"); ?></p>
                </div>
            </div>
            <div>
                <p style="font-weight:bold;">TO</p>
                <p><span style="font-weight:bold;">Customer Name : </span><?php echo $name; ?></p>
                <p><span style="font-weight:bold;">Phone Number : </span><?php echo $phone ?></p>
                <p><span style="font-weight:bold;">GST Number : </span><?php echo $gst; ?></p>
            </div>
            <div>
                <table class="tg" style="width:100%; height:100%;">
                    <tr>
                        <th class="tg-xldj">S.NO</th>
                        <th class="tg-xldj">Product Name</th>
                        <th class="tg-0pky">Brand</th>
                        <th class="tg-xldj">Color</th>
                        <th class="tg-xldj">Size</th>
                        <th class="tg-xldj">Qty.</th>
                        <th class="tg-xldj">Rate.</th>
                    </tr>
                    <?php
                        $whole_bill = "SELECT * FROM whole_items WHERE bill_code = '".$bill."'";
                        $whole_result = $connect->query($whole_bill);
                        while ($row = mysqli_fetch_array($whole_result)) {
        
                            $bill_number = $row['bill_code'];
                            $pname = $row['w_pname'];
                            $bname = $row['w_bname'];
                            $price = $row['w_price'];
                            $size = $row['w_size'];
                            $color = $row['w_color'];
                            $qty = $row['w_qty'];
        
                        $sno = 0;
                        $whole_sale_bill = "SELECT * FROM whole_sale_detail WHERE bill_code = '".$bill."'";
                        $whole_sale_result = $connect->query($whole_sale_bill);
                        while ($rowas = mysqli_fetch_array($whole_sale_result)){
        
                            $name = $rowas['w_name'];
                            $phone = $rowas['w_phone'];
                            $gst = $rowas['w_gst_number'];
                            $count_qty = $rowas['w_quantity'];
                            $total_sub = $rowas['w_subtotal'];
                            $disc = $rowas['w_discount'];
                            $amount_total = $rowas['w_total'];
                            $total_gst = $rowas['w_gst_total'];
                            $method_gst = $rowas['w_state_method'];
                            $amount_money = $rowas['w_cash'];

                            $sno = $sno + 1;
                    
                    ?>
                    <tr>
                        <td class="tg-xldj"></td>
                        <td class="tg-xldj"><?php echo $pname; ?></td>
                        <td class="tg-0pky"><?php echo $bname; ?></td>
                        <td class="tg-xldj"><?php echo $color; ?></td>
                        <td class="tg-xldj"><?php echo $size; ?></td>
                        <td class="tg-xldj"><?php echo $qty; ?></td>
                        <td class="tg-xldj"><?php echo $price; ?></td>
                    </tr>
                    <?php 
                            }
                        }
                    ?>
                    <tr>
                        <td class="tg-xldj" colspan="5" rowspan="4">Tax Amount in Words</td>
                        <td class="tg-xldj" colspan="1">IGST @ 18%</td>
                        <td class="tg-xldj"><?php echo $total_gst; ?></td>
                    </tr>
                    <tr>
                        <td class="tg-xldj" colspan="1">Subtotal</td>
                        <td class="tg-xldj"><?php echo $total_sub; ?></td>
                    </tr>
                    <tr>
                        <td class="tg-xldj" colspan="1">Discound %</td>
                        <td class="tg-xldj"><?php echo $disc; ?></td>
                    </tr>
                    <tr>
                        <td class="tg-xldj" colspan="1">Total Amount</td>
                        <td class="tg-xldj"><?php echo $amount_total; ?></td>
                    </tr>
                    <tr>
                        <td class="tg-0pky" colspan="4" rowspan="2">Goods once sold cannot be taken back or exchanged<br><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Party Signature</td>
                        <td class="tg-0pky" colspan="3" rowspan="2">For Roman's Seat Cover &amp; Helmets</td>
                    </tr>
                    <tr>
                    </tr>
                    <tr>
                    </tr>
                    <tr>
                    </tr>
                </table>
            </div>
        </div>
                
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        
    </body>
    </html>

<?php
    echo '<meta http-equiv="refresh" content="5; url=whole_sale.php">';
    unset($_SESSION["whole_billing"]);
    break;
    default:
        echo 'Bill Error Contact Navinprakash 9043728541 !!!';
    }
    }
    }
    }
    }
?>
