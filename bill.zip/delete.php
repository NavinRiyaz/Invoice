<?php

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST["delete"])) {

        $id = $_POST['del_id'];
        
        $query = "DELETE FROM products WHERE  p_id = '$id'";

        $result = mysqli_query($connect, $query);
               
        header("Location: products.php");

    }

?>