<?php

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['add_account'])) {
       
        $name = $_POST['name'];
        $bill_number = $_POST['bill_number'];
        $details = $_POST['details'];
        $address = $_POST['address'];
        $contact_number = $_POST['contact_number'];
        $today_date = $_POST['today_date'];
        $product_amount = $_POST['product_amount'];
        $initial_amount = $_POST['inital_amount'];
        $remaining_amount = $_POST['remaining_amount'];
        $gst = $_POST['gst_number'];

        $sql = "INSERT INTO wholesale_dealer(name, bill_no, gst_no, details, address, contact, today_date, product_amount, initial_amount, remaining_amount) 
        VALUES ('".$name."', '".$bill_number."', '".$gst."', '".$details."', '".$address."', '".$contact_number."', '".$today_date."', '".$product_amount."', '".$initial_amount."', '".$remaining_amount."')";

        $result = $connect->query($sql);

        if ($result === TRUE) {
                
            header("Location: accounts.php");
        }



    }








?>