<?php

    session_start();
    require_once 'dbconnect.php';

    $bcode = $_POST['barcodes'];
    $p_name = $_POST['w_pname'];
    $b_name = $_POST['w_bname'];
    $prz = $_POST['w_price'];
    $size = $_POST['w_size'];
    $color = $_POST['w_color'];
    $qty = $_POST['w_qty'];
    $dis = $_POST['w_disc'];
    $bill_code = $_POST['bill_codes'];

    $limit = count($bcode);

    for($i=0;$i<$limit;$i++) 
    {
        $barcode[$i] = mysqli_real_escape_string($connect,$bcode[$i]);
        $pname[$i] = mysqli_real_escape_string($connect,$p_name[$i]);
        $bname[$i] = mysqli_real_escape_string($connect,$b_name[$i]);
        $price[$i] = mysqli_real_escape_string($connect,$prz[$i]);
        $size[$i] = mysqli_real_escape_string($connect,$size[$i]);
        $color[$i] = mysqli_real_escape_string($connect,$color[$i]);
        $quantity[$i] = mysqli_real_escape_string($connect,$qty[$i]);
        $discount[$i] = mysqli_real_escape_string($connect, $dis[$i]);

        $amount_quantity[$i] = $price[$i] * $quantity[$i];
        $in_discount[$i] = ($discount[$i] / 100) * $amount_quantity[$i];
        $after_discount[$i] = $amount_quantity[$i] - $in_discount[$i];

        $sql = "INSERT INTO whole_items(bill_code, w_barcode, w_pname, w_bname, w_price, w_size, w_color, w_qty, w_amountqty, w_in_discount, w_afterdiscount, discount_percentage) 
        VALUES ('".$bill_code."', '".$barcode[$i]."', '".$pname[$i]."', '".$bname[$i]."', '".$price[$i]."', '".$size[$i]."', '".$color[$i]."', '".$quantity[$i]."', '".$amount_quantity[$i]."', '".$in_discount[$i]."', '".$after_discount[$i]."', '".$discount[$i]."')";

        if ($connect->query($sql) === TRUE) {

            $sql1 = "SELECT * FROM whole_items WHERE w_barcode = '".$barcode[$i]."'";
            $result1 = $connect->query($sql1);
            $checkrows = mysqli_num_rows($result1);
                if($checkrows > 0)
                {
                    while($row=mysqli_fetch_array($result1))
                    {
                        $qty_item = $row['w_qty'];
                        $barcode_item = $row['w_barcode'];
                    }
                    $sql2 = "UPDATE products SET qty = qty-'".$qty_item."' WHERE barcode = '".$barcode_item."'";
                    $result2 = $connect->query($sql2);
                }
        }
        else {
            echo "Error: " . $sql . "<br>" . $connect->error;
        }

    }



?>