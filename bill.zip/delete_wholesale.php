<?php
    session_start();
    require_once 'dbconnect.php';
    
    if (isset($_POST['delete'])) {
        error_reporting(0);
        $item_id = $_POST['code'];
        if (!empty($_SESSION["whole_sale_billing"])) {
            foreach ($_SESSION["whole_sale_billing"] as $select => $val) {
                if($val["barcode"] == $item_id)
                {
                    unset($_SESSION["whole_sale_billing"][$select]);
                }
            }
            header("Location: whole_sale.php");
        }
    }
?>