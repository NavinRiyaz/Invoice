<?php 

session_start();

require_once 'dbconnect.php';

// echo $_SESSION['userId'];

if(!$_SESSION['userId']) {
	header('location: index.php');	
}

  function generatePIN($digits = 4){
    $i = 0; //counter
    $pin = ""; //our default pin is blank.
    while($i < $digits){
        //generate a random number between 0 and 9.
        $pin .= mt_rand(1, 9);
        $i++;
    }
    return $pin;
  }
  $pin = generatePIN();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Admin Garuda
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/perfect-scrollbar.css">
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="http://www.adroitrix.tk" class="simple-text logo-normal">
          ADMIN GARUDA
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="./dashboard.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="./products.php">
              <i class="material-icons">shopping_basket</i>
              <p>Products</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./reports.php">
              <i class="material-icons">content_paste</i>
              <p>Reports</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./invoice.php">
              <i class="material-icons">library_books</i>
              <p>Invoice</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./whole_sale.php">
              <i class="material-icons">library_books</i>
              <p>Whole Sale</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./salesman.php">
              <i class="material-icons">person</i>
              <p>Salesman</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./return.php">
              <i class="material-icons">how_to_vote</i>
              <p>Return Product</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./accounts.php">
              <i class="material-icons">contact_mail</i>
              <p>Accounts</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./rtl.html">
              <i class="material-icons">language</i>
              <p>Contact and Credits</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#pablo">Add Products</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <button type="submit" class="btn btn-white btn-round btn-just-icon">
                  <i class="material-icons">search</i>
                  <div class="ripple-container"></div>
                </button>
              </div>
            </form>
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="material-icons">dashboard</i>
                  <p class="d-lg-none d-md-block">
                    Stats
                  </p>
                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="#pablo" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i>
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="dashboard.php">Dashboard</a>
                  <a class="dropdown-item" href="#">Settings</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="logout.php">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
        <span id="error"></span>
          <div class="row">
            <div class="col-md-12">
              <div class="card card-plain">
                <div class="card-header card-header-primary">
                  <h4 class="card-title mt-0">Add Products</h4>
                  <p class="card-category">Products Create with name and Specific brands</p>
                </div>
                <div class="card-body">
                  <form id="insert_form" method="POST">
                    <div class="full">
                      <div class="form-row" id="item_table">
                        <div class="col">
                          <input type="text" class="form-control" id="barcode" name="barcode[]" placeholder="Barcode" value="<?php echo $pin ?>">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" id="pname" name="pname[]" placeholder="Model Name">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" id="bname" name="bname[]" placeholder="Brand Name">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" id="price" name="price[]" placeholder="Price">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" id="size" name="size[]" placeholder="Size">
                        </div>
                        <div class="col">
                          <input type="text" class="form-control" id="color" name="color[]" placeholder="Color">
                        </div>
                        <!-- <div class="col">
                          <input type="text" class="form-control" id="discount" name="discount[]" placeholder="Discount">
                        </div> -->
                        <div class="col">
                          <input type="text" class="form-control" id="quantity" name="quantity[]" placeholder="Quantity">
                        </div>
                        <div class="col">
                          <button type="button" name="add" class="btn btn-primary btn-sm add">
                            <i class="material-icons">add</i> Add More
                          </button>
                        </div> 
                      </div>
                      <div class="text-center">
                        <button type="submit" id="submit" name="submit" class="btn btn-primary btn-sm">
                          <i class="material-icons">save</i> Save Products
                        </button>
                        <a href="products.php" class="btn btn-danger btn-sm">
                          <i class="material-icons">backspace</i> Back
                        </a>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
        <nav class="float-left">
            <ul>
              <li>
                <a href="https://www.about-navinprakash.ml">
                  Navinprakash
                </a>
              </li>
              <li>
                <a href="https://www.adroitrix.tk">
                  About Us
                </a>
              </li>
              <li>
                <a href="http://navinprakashronaldo.blogspot.com">
                  Blog
                </a>
              </li>
              <li>
                <a href="https://www.Garuda.ml">
                  About Garuda
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.adroitrix.tk" target="_blank">Adroitrix</a> for a better web.
          </div>
        </div>
      </footer>
    </div>
  </div>
  
  <!--   Core JS Files   -->
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="assets/js/perfect-scrollbar.js"></script>
  <!-- Plugin for the momentJs  -->
  <script src="assets/js/plugins/moment.min.js"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="assets/js/plugins/sweetalert2.js"></script>
  <!-- Forms Validations Plugin -->
  <script src="assets/js/plugins/jquery.validate.min.js"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="assets/js/plugins/jquery.bootstrap-wizard.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="assets/js/plugins/bootstrap-selectpicker.js"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="assets/js/plugins/jquery.dataTables.min.js"></script>
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="assets/js/plugins/bootstrap-tagsinput.js"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="assets/js/plugins/jasny-bootstrap.min.js"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="assets/js/plugins/fullcalendar.min.js"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="assets/js/plugins/jquery-jvectormap.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="assets/js/plugins/nouislider.min.js"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="assets/js/plugins/arrive.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="assets/js/material-dashboard.js?v=2.1.1" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="assets/demo/demo.js"></script>
    <script>
        new PerfectScrollbar('.input_fields');
    </script>
  <script>
    $(document).ready(function(){
      var i=1;
      $(document).on('click', '.add', function(){
        var bar  = $('#barcode').val();
        var calbar = parseInt(bar)+parseInt(i); 
        i++;
        var html = '';
        html += '<div class="card-body form-row" id="extra">';
        html += '<div class="col"><input type="text" value="'+calbar+'" class="form-control" name="barcode[]" placeholder="Barcode"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="pname[]" placeholder="Model Name"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="bname[]" placeholder="Brand Name"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="price[]" placeholder="Price"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="size[]" placeholder="Size"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="color[]" placeholder="Color"></div>';
        html += '<div class="col"><input type="text" class="form-control" name="quantity[]" placeholder="Quantity"></div>';
        html += '<div class="col"><button type="button" name="remove" class="btn btn-danger btn-sm remove"><i class="material-icons">remove</i> Remove</button></div>';
        html += '</div>';
        $('#item_table').append(html);
      });
      
      $(document).on('click', '.remove', function(){
        $(this).closest('#extra').remove();
      });

      $('#insert_form').on('submit', function(event){
          event.preventDefault();
          var error = '';
        $('#barcode').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter Barcode Number</span></div>';
            return false;
          }
          count = count + 1;
        });
          
        $('#pname').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter your Product Name</span></div>';
            return false;
          }
          count = count + 1;
        });
        $('#bname').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter your Brand Name</span></div>';
            return false;
          }
          count = count + 1;
        });
          
        $('#price').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter your Price</span></div>';
            return false;
          }
          count = count + 1;
        });
        $('#size').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter your Size</span></div>';
            return false;
          }
          count = count + 1;
        });
        $('#color').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter your Color</span></div>';
            return false;
          }
          count = count + 1;
        });
          
        // $('#discount').each(function(){
        //   var count = 1;
        //   if($(this).val() == '')
        //   {
        //     error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter Your Discount</span></div>';
        //     return false;
        //   }
        //   count = count + 1;
        // });

        $('#quantity').each(function(){
          var count = 1;
          if($(this).val() == '')
          {
            error += '<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Enter Your Quantity</span></div>';
            return false;
          }
          count = count + 1;
        });

        var form_data = $(this).serialize();
          if(error == '')
          {
          $.ajax({
            url:"saveproducts.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
              $('#extra').remove();
              $('#insert_form')[0].reset();
              $('#error').html('<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Data Successfully Saved</span></div>');
              var url = "products.php";    
              $(location).attr('href',url);
            }
          });
          }
          else
          {
          $('#error').html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="material-icons">close</i></button><span>Data Error</span>'+error+'</div>');
          }
        }); 

    });    
  </script> 
</body>

</html>
