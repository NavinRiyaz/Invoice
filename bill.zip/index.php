<?php
  require_once 'dbconnect.php';

  session_start();
  
  if(isset($_SESSION['userId'])) {
    header('location: dashboard.php');	
  }
  
  $errors = array();
  
  if($_POST) {		
  
    $username = $_POST['username'];
    $password = md5($_POST['password']);
  
    if(empty($username) || empty($password)) {
      if($username == "") {
        $errors[] = "Username is required";
      } 
  
      if($password == "") {
        $errors[] = "Password is required";
      }
    } else {
      $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
      $result = $connect->query($sql);
      $row = mysqli_fetch_assoc($result);
      $count = mysqli_num_rows($result);
      if($count==1){
        $_SESSION['userId']=array(
          'username'=> $row['username'],
          'password'=> $row['password'],
          'role'=> $row['role']
        );
        $role = $_SESSION['userId']['role'];
        //Redirecting User Based on Role
        switch($role){
        case 'user':
        header('location: employee.php');
        break;
        case 'manager':
        header('location: manager.php');
        break;
        case 'admin':
        header('location: dashboard.php');
        break;
      }
  
    } 
    
  } 

}
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
      <title>Admin Garuda</title>
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="icon" type="image/png" href="assets/img/logo.png">
</head>

<body>

  <div class="vid-container">
  <video class="bgvid" autoplay="autoplay" muted="muted" preload="auto" loop>
      <source src="assets/img/coverrr.mp4" type="video/webm">
  </video>
  <div class="inner-container">
    <video class="bgvid inner" autoplay="autoplay" muted="muted" preload="auto" loop>
      <source src="assets/img/coverrr.mp4" type="video/webm">
    </video>
    <form action="" method="post"><div class="box">
      <h1>ADMIN GARUDA</h1>
      <input type="text" name="username" placeholder="Username"/>
      <input type="password" name="password" placeholder="Password"/>
      <button type=submit name="login">Login</button>
      <!-- <p>Not a member? <span>Sign Up</span></p> -->
    </div>
  </form>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="assets/js/index.js"></script>

</body>

</html>
