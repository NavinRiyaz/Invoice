<?php

    session_start();
    require_once 'dbconnect.php';
    
    if (isset($_POST['submit'])) {

            $cust_name = $_POST['cust_name'];
            $cust_phone = $_POST['cust_phone'];
            $cust_gst = $_POST['cust_gst'];
            $quantity_count = $_POST['quantity_count'];
            $subtotal = $_POST['subtotal'];
            $discount = $_POST['totalDiscount'];
            $total_amount = $_POST['overalltotal'];
            $total_overall_amount = $_POST['overall'];
            $gst_total = $_POST['gsttotal'];
            $payment_option = $_POST['payment_method'];
            $state_method = $_POST['state'];
            $money = $_POST['money'];
            $bill = $_POST['bill_code'];

            $sql = "INSERT INTO sales(bill_code, cust_name, cust_phone, cust_gst, quantity_count, subtotal, discount, total_amount, total_overall, gst_total, payment_option, state_method, money_amount) 
            VALUES ('".$bill."', '".$cust_name."', '".$cust_phone."','".$cust_gst."', '".$quantity_count."', '".$subtotal."', '".$discount."', '".$total_amount."', '".$total_overall_amount."', '".$gst_total."', '".$payment_option."', '".$state_method."', '".$money."')";

            $result = $connect->query($sql);

            if ($result === TRUE) {
                
                $item_bill = "SELECT * FROM items WHERE bill_code = '".$bill."'";
                $item_result = $connect->query($item_bill);
                while ($row = mysqli_fetch_array($item_result)) {

                    $bill_number = $row['bill_code'];
                    $pname = $row['item_name'];
                    $bname = $row['item_brand'];
                    $price = $row['item_price'];
                    $size = $row['item_size'];
                    $color = $row['item_color'];
                    $qty = $row['item_qty'];


                $sales_bill = "SELECT * FROM sales WHERE bill_code = '".$bill."'";
                $sales_result = $connect->query($sales_bill);
                while ($rowas = mysqli_fetch_array($sales_result)){

                    $name = $rowas['cust_name'];
                    $phone = $rowas['cust_phone'];
                    $gst = $rowas['cust_gst'];
                    $count_qty = $rowas['quantity_count'];
                    $total_sub = $rowas['subtotal'];
                    $disc = $rowas['discount'];
                    $amount_total = $rowas['total_amount'];
                    $total_gst = $rowas['gst_total'];
                    $option_payment = $rowas['payment_option'];
                    $method_gst = $rowas['state_method'];
                    $amount_money = $rowas['money_amount'];
                    $overall_total = $rowas['total_overall'];

                switch($_POST['state']){
                case 'instate':
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Aclonica" rel="stylesheet">
        
        <style>
            body .container{
                border: black solid 2px;
            }
        </style>
        <style type="text/css">
            .tg  {border-collapse:collapse;border-spacing:0;}
            .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg .tg-xldj{border-color:inherit;text-align:left}
            .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
        </style>

        <title>Receipt</title>
    </head>
    <body onload="self.print()">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p><span style="font-weight:bold;">GSTIN</span> : 33AKIPR8911M1ZN <br> <span style="font-weight:bold;">STATE CODE</span> : 33</p>
                </div>
                <div class="col-md-4 text-center">
                    <p style="font-weight:bold; text-decoration: underline; font-size: 20px;">TAX INVOICE</p>
                </div>
                <div class="col-md-4 text-right">
                    <p><span style="font-weight:bold;">CELL</span> : 98430 75605</p>
                </div>
            </div>
            <div class="text-center">
                <p style="font-weight:bold; font-size: 30px;">ROMAN'S SEAT COVER & HELMETS</p>
                <p>224/115-K, Silver Arrow Complex, Opp. to Infant Jesus Church, <br> Omalur Main Road, (Near Four Roads), SALEM - 636007</p>
            </div>
            <div class="row">
                <div class="col">
                    <p class="text-left">Bill No: <?php echo $bill_number; ?></p>
                </div>
                <div class="col">
                    <p class="text-right"><span>Date : </span><?php echo date("Y/m/d"); ?></p>
                </div>
            </div>
            <div>
                <p style="font-weight:bold;">TO</p>
                <p><span style="font-weight:bold;">Customer Name : </span><?php echo $name; ?></p>
                <p><span style="font-weight:bold;">Phone Number : </span><?php echo $phone ?></p>
                <p><span style="font-weight:bold;">GST Number : </span><?php echo $gst; ?></p>
            </div>
            <div>
                <table class="tg" style="width:100%;">
                    <tr>
                      <th class="tg-s268">S.NO</th>
                      <th class="tg-s268" colspan="4">Product Name</th>
                      <th class="tg-s268">Brand</th>
                      <th class="tg-s268">Size</th>
                      <th class="tg-s268">Color</th>
                      <th class="tg-s268">Qty</th>
                      <th class="tg-s268">Rate</th>
                    </tr>
                    <?php
                        $item_bill = "SELECT * FROM items WHERE bill_code = '".$bill."'";
                        $item_result = $connect->query($item_bill);
                        while ($row = mysqli_fetch_array($item_result)) {
        
                            $bill_number = $row['bill_code'];
                            $pname = $row['item_name'];
                            $bname = $row['item_brand'];
                            $price = $row['item_price'];
                            $size = $row['item_size'];
                            $color = $row['item_color'];
                            $qty = $row['item_qty'];
        
                        $sno = 0;
                        $sales_bill = "SELECT * FROM sales WHERE bill_code = '".$bill."'";
                        $sales_result = $connect->query($sales_bill);
                        while ($rowas = mysqli_fetch_array($sales_result)){
        
                            $name = $rowas['cust_name'];
                            $phone = $rowas['cust_phone'];
                            $gst = $rowas['cust_gst'];
                            $count_qty = $rowas['quantity_count'];
                            $total_sub = $rowas['subtotal'];
                            $disc = $rowas['discount'];
                            $amount_total = $rowas['total_amount'];
                            $total_gst = $rowas['gst_total'];
                            $option_payment = $rowas['payment_option'];
                            $method_gst = $rowas['state_method'];
                            $amount_money = $rowas['money_amount'];
                            $overall_total = $rowas['total_overall'];

                            $gst_amount = $total_gst / 2; 

                            $sno = $sno + 1;
                    
                    ?>
                    <tr style="margin-top:-10px;">
                        <td class="tg-xldj"><?php echo $sno; ?></td>
                        <td class="tg-xldj" colspan="4"><?php echo $pname; ?></td>
                        <td class="tg-xldj"><?php echo $bname; ?></td>
                        <td class="tg-xldj"><?php echo $color; ?></td>
                        <td class="tg-xldj"><?php echo $size; ?></td>
                        <td class="tg-xldj"><?php echo $qty; ?></td>
                        <td class="tg-xldj"><?php echo $price; ?></td>
                    </tr>
                    <?php 
                            }
                        }
                    ?>
                    <tr>
                      <td class="tg-s268" colspan="8" rowspan="4">Tax Amount in Words</td>
                      <td class="tg-s268" colspan="1">SGST @ 9%</td>
                      <td class="tg-0lax"><?php echo $gst_amount; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">CGST @ 9%</td>
                      <td class="tg-0lax"><?php echo $gst_amount; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Discount</td>
                      <td class="tg-0lax"><?php echo $disc; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Total Amount</td>
                      <td class="tg-0lax"><?php echo $overall_total;?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="7" height="500">Goods once sold can't be taken back or Exchange</td>
                      <td class="tg-s268" colspan="4" height="500">for Roman's Seat Cover &amp; Helmets</td>
                    </tr>
                    <tr>
                    </tr>
                  </table>
            </div>
        </div>      
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        
    </body>
    </html>
<?php
    echo '<meta http-equiv="refresh" content="5; url=invoice.php">';
    unset($_SESSION["billing_table"]);
    break;
    case 'otherstate':
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link href="https://fonts.googleapis.com/css?family=Aclonica" rel="stylesheet">
        
        <style>
            body .container{
                border: black solid 2px;
            }
        </style>
        <style type="text/css">
            .tg  {border-collapse:collapse;border-spacing:0;}
            .tg td{font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg th{font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
            .tg .tg-xldj{border-color:inherit;text-align:left}
            .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
        </style>

        <title>Receipt</title>
    </head>
    <body onload="self.print()">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <p><span style="font-weight:bold;">GSTIN</span> : 33AKIPR8911M1ZN <br> <span style="font-weight:bold;">STATE CODE</span> : 33</p>
                </div>
                <div class="col-md-4 text-center">
                    <p style="font-weight:bold; text-decoration: underline; font-size: 20px;">TAX INVOICE</p>
                </div>
                <div class="col-md-4 text-right">
                    <p><span style="font-weight:bold;">CELL</span> : 98430 75605</p>
                </div>
            </div>
            <div class="text-center">
                <p style="font-weight:bold; font-size: 30px;">ROMAN'S SEAT COVER & HELMETS</p>
                <p>224/115-K, Silver Arrow Complex, Opp. to Infant Jesus Church, <br> Omalur Main Road, (Near Four Roads), SALEM - 636007</p>
            </div>
            <div class="row">
                <div class="col">
                    <p class="text-left">Bill No: <?php echo $bill_number; ?></p>
                </div>
                <div class="col">
                    <p class="text-right"><span>Date : </span><?php echo date("Y/m/d"); ?></p>
                </div>
            </div>
            <div>
                <p style="font-weight:bold;">TO</p>
                <p><span style="font-weight:bold;">Customer Name : </span><?php echo $name; ?></p>
                <p><span style="font-weight:bold;">Phone Number : </span><?php echo $phone ?></p>
                <p><span style="font-weight:bold;">GST Number : </span><?php echo $gst; ?></p>
            </div>
            <div>
            <table class="tg" style="width:100%;">
                    <tr>
                      <th class="tg-s268">S.NO</th>
                      <th class="tg-s268" colspan="4">Product Name</th>
                      <th class="tg-s268">Brand</th>
                      <th class="tg-s268">Size</th>
                      <th class="tg-s268">Color</th>
                      <th class="tg-s268">Qty</th>
                      <th class="tg-s268">Rate</th>
                    </tr>
                    <?php
                        $item_bill = "SELECT * FROM items WHERE bill_code = '".$bill."'";
                        $item_result = $connect->query($item_bill);
                        while ($row = mysqli_fetch_array($item_result)) {
        
                            $bill_number = $row['bill_code'];
                            $pname = $row['item_name'];
                            $bname = $row['item_brand'];
                            $price = $row['item_price'];
                            $size = $row['item_size'];
                            $color = $row['item_color'];
                            $qty = $row['item_qty'];
        
        
                        $sales_bill = "SELECT * FROM sales WHERE bill_code = '".$bill."'";
                        $sales_result = $connect->query($sales_bill);
                        while ($rowas = mysqli_fetch_array($sales_result)){
        
                            $name = $rowas['cust_name'];
                            $phone = $rowas['cust_phone'];
                            $gst = $rowas['cust_gst'];
                            $count_qty = $rowas['quantity_count'];
                            $total_sub = $rowas['subtotal'];
                            $disc = $rowas['discount'];
                            $amount_total = $rowas['total_amount'];
                            $total_gst = $rowas['gst_total'];
                            $option_payment = $rowas['payment_option'];
                            $method_gst = $rowas['state_method'];
                            $amount_money = $rowas['money_amount'];
                            $overall_total = $rowas['total_overall'];
                    
                    ?>
                    <tr>
                        <td class="tg-xldj"></td>
                        <td class="tg-xldj" colspan="4"><?php echo $pname; ?></td>
                        <td class="tg-xldj"><?php echo $bname; ?></td>
                        <td class="tg-xldj"><?php echo $color; ?></td>
                        <td class="tg-xldj"><?php echo $size; ?></td>
                        <td class="tg-xldj"><?php echo $qty; ?></td>
                        <td class="tg-xldj"><?php echo $price; ?></td>
                    </tr>
                    <?php 
                            }
                        }
                    ?>
                    <tr>
                      <td class="tg-s268" colspan="8" rowspan="4">Tax Amount in Words</td>
                      <td class="tg-s268" colspan="1">IGST @ 18%</td>
                      <td class="tg-0lax"><?php echo $total_gst; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Discount</td>
                      <td class="tg-0lax"><?php echo $disc; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="1">Total Amount</td>
                      <td class="tg-0lax"><?php echo $overall_total; ?></td>
                    </tr>
                    <tr>
                      <td class="tg-s268" colspan="7" height="500">Goods once sold can't be taken back or Exchange</td>
                      <td class="tg-s268" colspan="4" height="500">for Roman's Seat Cover &amp; Helmets</td>
                    </tr>
                    <tr>
                    </tr>
                  </table>
            </div>
        </div>
                
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        
    </body>
    </html>

<?php
    echo '<meta http-equiv="refresh" content="5; url=invoice.php">';
    unset($_SESSION["billing_table"]);
    break;
    default:
        echo 'Bill Error Contact Navinprakash 9043728541 !!!';
    }
    }
    }
    }
    }
?>