<?php

session_start();
require_once 'dbconnect.php';

if (isset($_POST['action']) && $_POST['action']=="change"){
    foreach($_SESSION["billing_table"] as &$value){
      if($value['barcode'] === $_POST["code"]){
          $value['quantity'] = $_POST["quantity"];
          break; // Stop the loop after we've found the product
        }
    }
    header("Location: invoice.php");

}


?>