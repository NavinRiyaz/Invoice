<?php 

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['bill_code'])) {
        
       $re_bill_no = $_POST['re_bill_no'];
       $cust_name = $_POST['re_cust_name'];
       $cust_phone = $_POST['re_cust_phone'];
       $quantity_count = $_POST['re_quantity_count'];
       $subtotal = $_POST['re_subtotal'];
       $discount = $_POST['re_totalDiscount'];
       $total = $_POST['re_overalltotal'];
       $gst = $_POST['re_gsttotal'];
       $money = $_POST['re_money'];
       $bill_code = $_POST['bill_code'];
       $remarks = $_POST['re_bill_no'];
       $barcodes = $_POST['barcodes'];

       $sql = "INSERT INTO return_products(re_bill_code, re_barcode, re_cust_name, re_phone_no, re_qty_count, re_subtotal, re_discount, re_total_amount, re_gst_total, re_money_amount, remarks) 
       VALUES ('".$bill_code."', '".$barcodes."', '".$cust_name."', '".$cust_phone."', '".$quantity_count."', '".$subtotal."', '".$discount."', '".$total."', '".$gst."', '".$money."', '".$remarks."')";

       $result = $connect->query($sql);

       if ($result === TRUE) {       
        header("Location: return.php");
       }

    }















?>