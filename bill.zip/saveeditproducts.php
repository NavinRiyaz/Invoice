<?php

    session_start();

    require_once 'dbconnect.php';

    if (isset($_POST['insert'])) {

        $id = $_POST['employee_id'];
        $pr_name = $_POST['epname'];
        $br_name = $_POST['ebname'];
        $ed_price = $_POST['eprice'];
        $ed_type = $_POST['etype'];
        $ed_dis = $_POST['ediscount'];

        $sql = "UPDATE products SET pname='$pr_name', bname='$br_name', price='$ed_price', type='$ed_type', discount='$ed_dis' WHERE p_id='$id'";

        if($connect->query($sql) === TRUE) {
            header("Location: products.php");	
        } else {
            echo "Product Doesnt inserted contact Administrator";
        }
    }



?>