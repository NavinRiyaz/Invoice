<?php  
    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['update'])) {

        $id = $_POST['pro_id'];
        $quantity = $_POST['uqty'];
        $bar = $_POST['bar'];

        $sql = "UPDATE products SET qty = '$quantity' WHERE p_id = '$id'";

        $sql1 = "INSERT INTO update_products(barcode, update_qty) VALUES ('".$bar."', '".$quantity."')";

        if ($connect->query($sql) === TRUE) {

            if($connect->query($sql1) === TRUE) {
                header("Location: products.php");
            } else {
                echo 'cancel';
            }

        }
        else {
            echo 'cancel';
        }
    }

 
?>