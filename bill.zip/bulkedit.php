<?php

    session_start();
    require_once 'dbconnect.php';

    $sql = "SELECT * FROM products";
    
    $result = $connect->query($sql);

    $connect->close();
?>