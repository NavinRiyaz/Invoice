<?php  
 //fetch.php  
 session_start();
 require_once 'dbconnect.php';
 if(isset($_POST["employee_id"]))  
 {  
      $query = "SELECT * FROM products WHERE p_id = '".$_POST["employee_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>