<?php 

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['add_sales'])) {
        
        $sales_number = $_POST['sales_number'];
        $sales_name = $_POST['sales_name'];
        $sales_phone = $_POST['sales_phone'];
        $sales_address = $_POST['sales_address'];
        $sales_aadhar = $_POST['sales_aadhar'];
        $sales_pan = $_POST['sales_pan'];
        $sales_username = $_POST['sales_username'];
        $sales_password = $_POST['sales_password'];
        $blood = $_POST['blood_group'];
        $joining_date = $_POST['joining_date'];
        $power = $_POST['power'];

        $sql = "INSERT INTO salesman(sales_number, sales_name, sales_phone, sales_address, sales_aadhar, sales_pan, sales_username, sales_password, power, blood_group, joining_date) 
        VALUES ('".$sales_number."', '".$sales_name."', '".$sales_phone."', '".$sales_address."', '".$sales_aadhar."', '".$sales_pan."', '".$sales_username."', '".$sales_password."', '".$power."', '".$blood."', '".$joining_date."')";

        $result = $connect->query($sql);

        if ($result === TRUE) {
            
           $sql1 = "INSERT INTO users(username, password, role) 
           VALUES ('".$sales_username."', '".$sales_password."', '".$power."')";
           $result1 = $connect->query($sql1);
           if ($result1) {
               
                header("Location: salesman.php");

           }

        }


    }



















?>