<?php
    session_start();
    require_once 'dbconnect.php';
    
    if (isset($_POST['delete'])) {
        $sql = "UPDATE products SET qty = qty+1 WHERE barcode = '".$_POST['code']."'";
        $result = $connect->query($sql);
        error_reporting(0);
        $item_id = $_POST['code'];
        if (!empty($_SESSION["billing_table"])) {
            foreach ($_SESSION["billing_table"] as $select => $val) {
                if($val["barcode"] == $item_id)
                {
                    unset($_SESSION["billing_table"][$select]);
                }
            }
            header("Location: invoice.php");
        }
    }
?>