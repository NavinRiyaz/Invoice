<?php

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST['update'])) {
        
        $today_date = $_POST['new_amount_date'];
        $update_amount = $_POST['new_amount'];
        $already_amount = $_POST['exist_amt'];
        $bill = $_POST['pro_id'];

        $sql = "INSERT INTO wholesale_dealer_update(bill_no, update_date, update_amount, previous_existing_amt) 
        VALUES ('".$bill."', '".$today_date."', '".$update_amount."', '".$already_amount."')";

        $result = $connect->query($sql);
        
        if ($result === TRUE) {
            
            $sql1 = "UPDATE wholesale_dealer SET initial_amount = initial_amount + '".$update_amount."' ,remaining_amount = remaining_amount - '".$update_amount."' WHERE bill_no = '".$bill."'";
            $result1 = $connect->query($sql1);

            if ($result1 === TRUE) {
                
                header("Location: accounts.php");


            }

        }







    }







?>