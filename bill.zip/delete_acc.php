<?php

    session_start();
    require_once 'dbconnect.php';

    if (isset($_POST["delete"])) {

        $id = $_POST['del_id'];
        
        $query = "DELETE FROM wholesale_dealer WHERE  bill_no = '$id'";

        $result = mysqli_query($connect, $query);
               
        header("Location: accounts.php");

    }

?>